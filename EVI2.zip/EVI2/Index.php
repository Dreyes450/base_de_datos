<!-- index.php -->
<?php
    // Incluir el archivo de cabecera
    include('private/shared/header.php');
    
?>
    <html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cocina Fácil - Tu espacio culinario</title>
    <link rel="stylesheet" href="public/Style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
</head>
<body>
    <main>
        <section class="hero">
            <div class="hero-content animate__animated animate__fadeInUp">
                <h2>Descubre el Arte de Cocinar</h2>
                <p>Miles de recetas, tips y una comunidad que comparte tu pasión.</p>
                <div class="search-bar">
                    <input type="text" id="search-input" placeholder="Buscar recetas...">
                    <button onclick="searchContent()">Buscar</button>
                </div>
                <div id="filter-results"></div>
            </div>
        </section>

        <!-- Carrusel de imágenes -->
        <section class="carousel">
            <div class="carousel-container">
                <div class="carousel-item animate__animated animate__fadeIn">
                    <img src="image1.jpg" alt="Imagen 1">
                </div>
                <div class="carousel-item animate__animated animate__fadeIn">
                    <img src="image2.jpg" alt="Imagen 2">
                </div>
                <div class="carousel-item animate__animated animate__fadeIn">
                    <img src="image3.jpg" alt="Imagen 3">
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="footer-content animate__animated animate__fadeIn">
            <div class="footer-section">
                <h4>Cocina Fácil</h4>
                <p>Tu espacio culinario digital</p>
            </div>
            <div class="footer-section">
                <h4>Enlaces</h4>
                <a href="#">Contacto</a>
            </div>
            <div class="footer-section">
                <h4>Síguenos</h4>
                <div class="social-links">
                    <a href="https://www.facebook.com/daniel.reyesmartinez.7737?locale=es_LA">
                        <i class="fab fa-facebook"></i>
                    </a>
                    <a href="https://www.instagram.com/reyesm_450/">
                        <i class="fab fa-instagram"></i>
                    </a>
                </div>
            </div>
        </div>
    </footer>

    <script>
        // Menú desplegable
        document.querySelector('.dropbtn').addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector('.dropdown-content').classList.toggle('show');
        });

        // Buscar y filtrar resultados
        function searchContent() {
            var query = document.getElementById('search-input').value.toLowerCase();
            document.getElementById('filter-results').innerHTML = `Resultados para: ${query}`;
        }

        // Efectos visuales con animaciones CSS
        $(document).ready(function () {
            $(".carousel-item").on("mouseenter", function () {
                $(this).addClass("animate__pulse");
            }).on("mouseleave", function () {
                $(this).removeClass("animate__pulse");
            });

            $(".login-btn").on("click", function () {
                $(this).addClass("animate__tada");
            });

            $(".footer-content").waypoint(function (direction) {
                if (direction === "down") {
                    $(this).addClass("animate__fadeInUp");
                }
            }, { offset: "80%" });
        });
    </script>
</body>
<?php
    // Incluir el archivo de pie de página
    include('private/shared/footer.php');
?>
