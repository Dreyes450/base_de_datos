<?php 
require_once('../../../private/initialize.php'); 
if (is_post_request()) { 
$pelicula = []; 
$pelicula['id'] = $_POST['id'] ?? ''; 
$pelicula['nombre_pelicula'] = $_POST['nombre'] ?? ''; 
$pelicula['genero_pelicula'] = $_POST['genero'] ?? ''; 
$pelicula['clasificacion_pelicula'] = $_POST['clasificacion'] ?? ''; 
$pelicula['duracion_pelicula'] = $_POST['duracion'] ??''; 
$pelicula['img_poster'] = $_POST['poster'] ?? ''; 
$result = insert_movie($pelicula); 
if ($result === true) {
$new_id = mysqli_insert_id($db); 
$_SESSION['message'] = 'La pelicula se creó exitosamente.'; 
redirect_to(url_for('/admin/peliculas/index.php')); 
} else { 
$errors = $result; 
} 
} else { 
$pelicula = []; 
$pelicula['id'] = $_GET['id'] ?? '1'; 
$pelicula['nombre_pelicula'] = ''; 
$pelicula['genero_pelicula'] = ''; 
$pelicula['clasificacion_pelicula'] = ''; 
$pelicula ['duracion_pelicula'] = ''; 
$pelicula['img_poster'] = ''; 
}
?>
<?php $page_title = 'Nueva pelicula'; ?> 
<?php include(SHARED_PATH . '/admin_header.php'); ?> 
<section class="page-content"> 
<div id="content"> 
<a class="back-link" href="<?php echo 
url_for('/admin/peliculas/index.php'); ?>">&laquo; Volver a la lista</a> 
<div class="page new"> 
<h1>A&ntilde; ade una pel&iacute;cula</h1> 
<form action="<?php echo url_for('/admin/peliculas/new.php'); ?>" 
method="post"> 
<dl> 
<dt>Nombre de la pel&iacute;cula</dt> 
<dd><input type="text" name="nombre" value="<?php echo 
htmlspecialchars($pelicula['nombre_pelicula']); ?>" /> 
</dd> 
</dl> 
<dl> 
<dt>G&eacute; nero de la pel&iacute;cula</dt> 
<dd> 
<input type="text" name="genero" value="<?php echo 
htmlspecialchars($pelicula ['genero_pelicula']); ?>" /> 
</dd> 
</dl> 
<dl> 
<dt>Clasificaci&oacute;n de la pel&iacute;cula</dt> 
<dd> 
<input type="text" name="clasificacion" 
value="<?php echo 
htmlspecialchars($pelicula['clasificacion_pelicula']); ?>" /> 
</dd> 
</dl> 
<dl> 
<dt>Duraci&oacute;n de la pel&iacute;cula</dt> 
<dd> 
<input type="text" name="duracion" 
value="<?php echo 
htmlspecialchars($pelicula['duracion_pelicula']); ?>" /> 
</dd> 
</dl> 
<dl> 
<dt>Link al poster</dt> 
<dd> 
<input type="text" name="poster" value="<?php echo 
htmlspecialchars($pelicula['img_poster']); ?>" /> 
</dd> 
</dl> 
<div id="operations">
<input type="submit" value="A&ntilde;ade una pel&iacute;cula" 
class="nice_btn" /> 
</div> 
</form> 
</div> 
</div> 
<?php include(SHARED_PATH . '/admin_footer.php'); ?>
