<?php require_once('../../../private/initialize.php'); 
if (!isset($_GET['id'])) { 
redirect_to(url_for('/admin/peliculas/index.php')); 
} 
$id = $_GET['id']; 
if (is_post_request()) { 
$pelicula = []; 
$pelicula['id'] = $id; 
$pelicula['nombre_pelicula'] = $_POST['nombre'] ?? ''; 
$pelicula['genero_pelicula'] = $_POST['genero'] ?? ''; 
$pelicula['clasificacion_pelicula'] = $_POST['clasificacion'] ?? '';
$pelicula['duracion_pelicula'] = $_POST['duracion'] ?? ''; 
$pelicula['img_poster'] = $_POST['poster'] ?? ''; 
$result = update_movie($pelicula); 
if ($result === true) { 
$_SESSION['message'] = 'La pelicula se editó exitosamente.'; 
redirect_to(url_for('/admin/peliculas/index.php')); 
} else { 
$errors = $result; 
} 
} else { 
$pelicula = find_movie_by_id($id); 
}
?> 
<?php $page_title = 'Editar pelicula'; ?> 
<?php include (SHARED_PATH . '/admin_header.php'); ?> 
<section class="page-content"> 
<div id="content"> 
<?php 
$query = "SELECT * FROM catalogo_peliculas WHERE id = ?"; 
$stmt = $db->prepare($query); 
$stmt->bind_param("i", $id); 
$stmt->execute(); 
$result = $stmt->get_result(); 
$pelicula  = $result->fetch_assoc() ?> 
<a class="back-link" href="<?php echo 
url_for('/admin/peliculas/index.php'); ?>">&laquo; Volver a la lista</a> 
<div class="subject edit">
<h1>Editar pel&iacute;cula</h1> 
<form action="<?php echo 
url_for('/admin/peliculas/edit.php?id='. 
htmlspecialchars(urlencode($id))); ?>" 
method="post"> 
<dl> 
<dt>Nombre de la pel&iacute;cula</dt> 
<dd><input type="text" name="nombre" 
value="<?php echo 
htmlspecialchars($pelicula['nombre_pelicula']); ?>" /> 
</dd> 
</dl> 
<dl> 
<dt>G&eacute; nero de la pel&iacute;cula</dt> 
<dd> 
<input type="text" name="genero" 
value="<?php echo 
htmlspecialchars($pelicula['genero_pelicula']); ?>" /> 
</dd> 
</dl> 
<dl> 
<dt>Clasificaci&oacute;n de la pel&iacute;cula</dt> 
<dd> 
<input type="text" name="clasificacion" 
value="<?php echo 
htmlspecialchars($pelicula['clasificacion_pelicula']); ?>" /> 
</dd> 
</dl> 
<dl> 
<dt>Duraci&oacute;n de la pel&iacute;cula</dt> 
<dd> 
<input type="text" name="duracion" 
value="<?php echo 
htmlspecialchars($pelicula['duracion_pelicula']); ?>" /> 
</dd> 
</dl> 
<dl> 
<dt>Link al poster</dt> 
<dd> 
<input type="text" name="poster" 
value="<?php echo 
htmlspecialchars($pelicula['img_poster']); ?>" />
</dd> 
</dl> 
<div id="operations"> 
<input type="submit" value="Edita la pel&iacute;cula" 
class="nice btn" /> 
</div> 
</form> 
</div> 
</div> 
<?php include(SHARED_PATH . '/admin_footer.php'); ?>
