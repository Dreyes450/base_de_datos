<?php require_once('../../../private/initialize.php');
$page_title = 'Administración'; ?> 
<?php include (SHARED_PATH. '/admin_header.php'); ?> 
<section class="page-content"> 
<section class="container peliculas"> 
<?php 
$query = "SELECT * FROM catalogo_peliculas"; 
$stmt = $db->prepare($query); 
$stmt->execute(); 
$result = $stmt->get_result(); 
while ($subject = $result->fetch_assoc()) { ?> 
<div class="column"> 
<article class="poster"> 
<div class="poster_sections"> 
<img src="<?php echo 
url_for($subject['img_poster']); ?>" alt="Poster de la película 1"> 
</div> 
<div class="posterText poster_sections"> 
<h2> 
<?php echo $subject['nombre_pelicula']; ?> 
</h2> 
<p class="folio">Folio: 
<?php echo $subject['id']; ?> 
</p> 
<p>Tipo de pel&iacute;cula: 
<?php echo $subject['genero_pelicula']; ?> 
</p> 
<p>Clasificaci&oacute;n: 
<?php echo 
$subject['clasificacion_pelicula']; ?> 
</p> 
<ul> 
<li><a class="action" 
href="<?php echo 
url_for('/admin/peliculas/edit.php?id='. 
htmlspecialchars(urlencode($subject['id']))); ?>">Editar</a> 
</li> 
<li><a class="action" 
href="<?php echo 
url_for('/admin/peliculas/delete.php?id='. 
htmlspecialchars(urlencode($subject['id']))); ?>">Borrar</a>
</li> 
</ul> 
</div> 
</article> 
</div> 
<?php } ?> 
<?php 
$stmt->close(); 
$db->close(); 
?> 
</section> 
<section class="container"> 
<div id="operations"> 
<a class="action" href="<?php echo 
url_for('/admin/peliculas/new.php'); ?>"> 
<button class="nice_btn">Añade una película</button> 
</a> 
</div> 
</section> 
<?php include(SHARED_PATH . '/admin_footer.php'); ?>
