<?php 
require_once('../../../private/initialize.php'); 
if (!isset($_GET['id'])) { 
redirect_to(url_for('/admin/peliculas/index.php')); 
}

$id = $_GET['id']; 
if (is_post_request()) { 
$result = delete_movie($id); 
$_SESSION['message'] = 'La película se borró exitosamente.'; 
redirect_to(url_for('/admin/peliculas/index.php')); 
} else { 
$pelicula = find_movie_by_id($id); 
}
?>

<?php $page_title = 'Borrar pelicula'; ?> 
<?php include (SHARED_PATH . '/admin_header.php'); ?> 
<section class="page-content"> 
<div id="content"> 
<a class="back-link" href="<?php echo 
url_for('/admin/peliculas/index.php'); ?>">&laquo; Volver a la lista</a> 
<div class="subject delete"> 
<h1>Borrar pel&iacute;cula</h1> 
<p>¿Estas seguro(a) de que quieres borar esta 
pel&iacute;cula?</p> 
<p class="item"> 
<?php echo 
htmlspecialchars($pelicula['nombre_pelicula']); ?> 
</p> 
<form action="<?php echo 
url_for('/admin/peliculas/delete.php?id='. 
htmlspecialchars(urlencode($pelicula['id']))); ?>" method="post"> 
<div id="operations"> 
<input type="submit" name="commit" value="Delete 
Subject" class="nice_btn"/> 
</div> 
</form> 
</div> 
</div> 
<?php include (SHARED_PATH .'/admin_footer.php'); ?>