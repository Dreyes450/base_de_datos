<?php require_once('../../private/initialize.php');?> 
<?php $page_title = 'Panel de Admiminstración';?> 
<?php include (SHARED_PATH. '/header.php');?> 
<section class="page-content" id="mainadmin"> 
<div class="container" id="content"> 
<div class="mainadmin column"> 
<article class="seccion"> 
<h2>Bienvenido Administrador</h2> 
<h3>¿Qu&eacute; quieres hacer?</h3> 
<ul> 
<li><a href="<?php echo url_for('/admin/peliculas/index.php'); 
?>">Editar pel&iacute;culas</a></li> 
<li><a href="<?php echo url_for('/admin/peliculas/new.php'); 
?>">Agregar pel&iacute;cula</a></li> 
</ul> 
</article> 
</div> 
</div> 
<?php include (SHARED_PATH. '/admin_footer.php');?>
