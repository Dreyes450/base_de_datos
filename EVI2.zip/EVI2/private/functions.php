<?php 
  // Función para conectarse a la base de datos 
  function db_connect()
  {
    $connection = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
    // Verificar si se ha conectado a la base de datos correctamente 
    confirm_db_connect();
    return $connection;
  }

  // Función para verificar si la conexión a la base de datos se ha realizado correctamente 
  function confirm_db_connect()
  {
    if (mysqli_connect_errno()) {
      $msg = "Database connection failed: ";
      $msg .= mysqli_connect_error();
      $msg .= " (" . mysqli_connect_errno() . ")";
      // Si la conexión a la base de datos falla, se muestra un mensaje de error y se detiene el script
      exit($msg);
    }
  }

  // Función para desconectar de la base de datos 
  function db_disconnect($connection)
  {
    if (isset($connection)) {
      mysqli_close($connection);
    }
  }

  // Función para agregar la ruta relativa de un archivo 
  function url_for($script_path)
  {
    // Agregar la barra diagonal inicial si no está presente 
    if ($script_path[0] != '/') {
      $script_path = "/" . $script_path;
    }
    // Devolver la ruta completa a partir de la raíz del sitio web 
    return WWW_ROOT . $script_path;
  }

//Estas son dos funciones en PHP que permiten verificar si la solicitud actual es una solicitud POST o GET.
function redirect_to($location) 
{ 
header("Location:" . location); 
exit;
}

function is_post_request() 
{ 
return $_SERVER['REQUEST_METHOD'] == 'POST'; 
} 
function is_get_request() 
{ 
return $_SERVER['REQUEST_METHOD'] == 'GET';
}



function find_movie_by_id($id, $options = []) 
{
global $db; 
$stmt = mysqli_prepare($db, "SELECT * FROM catalogo_peliculas WHERE 
id = ?"); 
mysqli_stmt_bind_param($stmt, "i", $id); 
mysqli_stmt_execute($stmt); 
$result = mysqli_stmt_get_result($stmt); 
if (!$result) { 
exit("Database query failed."); 
} 
$subject = mysqli_fetch_assoc($result); 
mysqli_free_result($result); 
return $subject;
}

//Esta función actualiza los valores de una película en la tabla catalogo_peliculas de nuestra base de datos.
function insert_movie($pelicula) 
{ 
global $db; 
$sql = "INSERT INTO catalogo_peliculas  SET";

$sql .= "(id, nombre_pelicula, genero_pelicula, clasificacion_pelicula, duracion_pelicula, img_poster) "; 
$sql.= "VALUES (?, ?, ?, ?, ?, ?)"; 
$sql.= "nombre_pelicula=?, "; 
$sql.= "genero_pelicula=?, "; 
$sql.= "clasificacion_pelicula=?, "; 
$sql.= "duracion_pelicula=?, "; 
$sql.= "img_poster=? "; 
$sql.= "WHERE id=? "; 
$sql.= "LIMIT 1";
$stmt = mysqli_prepare($db, $sql); 
mysqli_stmt_bind_param($stmt, 'isssss', $pelicula['id'], 
$pelicula['nombre_pelicula'], $pelicula ['genero_pelicula'],
$pelicula ['clasificacion_pelicula'], $pelicula['duracion_pelicula'], $pelicula['img_poster']);  
$result = mysqli_stmt_execute($stmt); 

if ($result)
 { 
  return true; 
 } 

else { 
echo mysqli_error($db); 
db_disconnect($db); 
exit;
}
}


//Esta función actualiza los valores de una película en la tabla catalogo_peliculas de nuestra base de datos.
function update_movie($pelicula) 
{ 
global $db; 
$sql = "UPDATE catalogo_peliculas SET "; 
$sql .= "nombre_pelicula=?, "; 
$sql.= "genero_pelicula=?, "; 
$sql.= "clasificacion_pelicula=?, "; 
$sql.= "duracion_pelicula=?, "; 
$sql.= "img_poster=? "; 
$sql.= "WHERE id=? "; 
$sql.= "LIMIT 1"; 
$stmt = mysqli_prepare($db, $sql); 
mysqli_stmt_bind_param($stmt, 'sssssi', $pelicula ['nombre_pelicula'], 
$pelicula['genero_pelicula'], $pelicula ['clasificacion_pelicula'], 
$pelicula['duracion_pelicula'], $pelicula['img_poster'], 
$pelicula ['id']); 
$result = mysqli_stmt_execute($stmt); 
if ($result) { 
return true; 
} else { 
echo mysqli_error($db); 
db_disconnect($db); 
exit;
}
}

//Esta última función se usa para eliminar una película de la base de datos.
function delete_movie($id) { 
  global $db; 
  $sql = "DELETE FROM catalogo_peliculas"; 
  $sql.= "WHERE id=? "; 
  $sql.= "LIMIT 1"; 
  $stmt = mysqli_prepare($db, $sql); 
  mysqli_stmt_bind_param($stmt, 'i', $id); 
  $result = mysqli_stmt_execute($stmt); 
  if($result) { 
  return true; 
  } else { 
  echo mysqli_error($db); 
  db_disconnect($db); 
  exit; 
  }
}
?>