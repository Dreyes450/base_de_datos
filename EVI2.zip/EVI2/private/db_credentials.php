<?php 

	  define('DB_SERVER', '127.0.0.1:4306'); // IP + puerto

	  define("DB_USER", "root");

	  define("DB_PASS",  "");

	  define("DB_NAME", "recetas");

	  ?> 