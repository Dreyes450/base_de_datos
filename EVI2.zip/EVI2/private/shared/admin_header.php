<?php 
if (!isset($page_title)) { 
$page_title= 'Area de administración'; 
} 
?> 
<!DOCTYPE html> 
<html> 
<head> 
<meta charset="UTF-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<title>Cinema Ticket -
<?php echo htmlspecialchars($page_title); ?> 
</title> 
<link rel="stylesheet" href="<?php echo 
url_for('admin/css/admin_style.css') ?>"> 
</head> 
<body> 
<header class="page-header"> 
<nav> 
<a href="<?php echo url_for('/index.php') ?>" aria-label="CinemaTicket logo" class="logo"> 
<img src="<?php echo url_for('img/logo-dark.png') ?>" 
width="190" height="52" alt="Logotipo del sitio de CinemaTicket"> 
</a> 
<button class="toggle-mob-menu" aria-expanded="false" aria-
label="open menu"> 
<svg width="20" height="20" aria-hidden="true"> 
<use xlink:href="#down"></use> 
</svg> 
</button> 
<ul class="admin-menu"> 
<li class="menu-heading"> 
<h3>Admin</h3> 
</li> 
<li> 
<a href="<?php echo url_for('/admin/index.php') ?>"> 
</a> 
<span>Volver a administraci&oacute;n</span> 
</li> 
<li> 
<a href="<?php echo 
url_for('/admin/peliculas/index.php'); ?>"> 
<span>Pel&iacute; culas</span> 
</a> 
</li> 
<li> 
<button class="collapse-btn" aria-expanded="true" 
aria-label="collapse menu">