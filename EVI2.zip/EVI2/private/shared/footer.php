<!-- footer.php -->
<footer class="py-4 bg-dark text-white">
    <div class="container text-center">
        <p>&copy; 2025 Cinema Ticket - Todos los derechos reservados</p>
        <div class="social-links">
            <a href="https://www.facebook.com/daniel.reyesmartinez.7737?locale=es_LA" class="text-white me-3">Facebook</a>
            <a href="https://www.instagram.com/reyesm_450/" class="text-white me-3">Instagram</a>
            <a href="#" class="text-white me-3">Twitter</a>
        </div>
    </div>
</footer>
