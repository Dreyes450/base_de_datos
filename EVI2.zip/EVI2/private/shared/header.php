<header>
        <nav class="main-nav">
            <div class="logo">
                <h1>Cocina Fácil</h1>
            </div>
            <div class="nav-links">
                <a href="#" class="active">Inicio</a>
                <a href="#">Recetas</a>
                <a href="#">Blog</a>
                <a href="#">Comunidad</a>
                <div class="dropdown">
                    <a href="#" class="dropbtn">Menú</a>
                    <div class="dropdown-content">
                        <a href="#">Inicio</a>
                        <a href="#">Recetas</a>
                        <a href="#">Blog</a>
                    </div>
                </div>
                <a href="#" class="login-btn">Iniciar Sesión</a>
            </div>
        </nav>
    </header>